#!/bin/bash

DIR=/opt/tibco/ftl/5.2

if [ -e /etc/redhat-release ]
then
  alternatives  --install /usr/lib/libtibgroup.so libtibgroup $DIR/lib/libtibgroup.so 100
  alternatives  --install /usr/lib/libtibmast.so  libtibmcast $DIR/lib/libtibmcast.so 100
  alternatives  --install /usr/lib/libtibrdma.so  libtibrdma  $DIR/lib/libtibrdma.so  100
  alternatives  --install /usr/lib/libtib.so      libtib      $DIR/lib/libtib.so      100
  alternatives  --install /usr/lib/libtibstore.so libtibstore $DIR/lib/libtibstore.so 100
  alternatives  --install /usr/lib/libtibutil.so  libtibutil  $DIR/lib/libtibutil.so  100
  alternatives  --install /usr/lib/libnghttp2.so  libnghttp2  $DIR/lib/libnghttp2.so  100
  alternatives  --install /usr/lib/libnghttp2.so.14  libnghttp2.14  $DIR/lib/libnghttp2.so.14  100
elif [ -e /etc/debian_version ] || [ -e /etc/SuSE-release ]
then
  update-alternatives --install /usr/lib/libtibgroup.so libtibgroup $DIR/lib/libtibgroup.so 100
  update-alternatives --install /usr/lib/libtibmast.so  libtibmcast $DIR/lib/libtibmcast.so 100
  update-alternatives --install /usr/lib/libtibrdma.so  libtibrdma  $DIR/lib/libtibrdma.so  100
  update-alternatives --install /usr/lib/libtib.so      libtib      $DIR/lib/libtib.so      100
  update-alternatives --install /usr/lib/libtibstore.so libtibstore $DIR/lib/libtibstore.so 100
  update-alternatives --install /usr/lib/libtibutil.so  libtibutil  $DIR/lib/libtibutil.so  100
  update-alternatives --install /usr/lib/libnghttp2.so  libnghttp2  $DIR/lib/libnghttp2.so  100
  update-alternatives --install /usr/lib/libnghttp2.so.14  libnghttp2.14  $DIR/lib/libnghttp2.so.14  100
fi

