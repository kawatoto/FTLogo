#!/bin/bash

DIR=/opt/tibco/ftl/5.2

if [ -e /etc/redhat-release ]
then
  alternatives  --remove  libtibgroup $DIR/lib/libtibgroup.so
  alternatives  --remove  libtibmcast $DIR/lib/libtibmcast.so
  alternatives  --remove  libtibrdma  $DIR/lib/libtibrdma.so
  alternatives	--remove  libtib      $DIR/lib/libtib.so
  alternatives  --remove  libtibstore $DIR/lib/libtibstore.so
  alternatives  --remove  libtibutil  $DIR/lib/libtibutil.so
  alternatives  --remove  libnghttp2  $DIR/lib//libnghttp2.so
  alternatives  --remove  libnghttp2.14  $DIR/lib//libnghttp2.so.14
elif [ -e /etc/debian_version ] || [ -e /etc/SuSE-release ]
then
  update-alternatives --remove  libtibgroup $DIR/lib/libtibgroup.so
  update-alternatives --remove  libtibmcast $DIR/lib/libtibmcast.so
  update-alternatives --remove  libtibrdma  $DIR/lib/libtibrdma.so
  update-alternatives --remove  libtib      $DIR/lib/libtib.so
  update-alternatives --remove  libtibstore $DIR/lib/libtibstore.so
  update-alternatives --remove  libtibutil  $DIR/lib/libtibutil.so
  update-alternatives --remove  libnghttp2  $DIR/lib/libnghttp2.so
  update-alternatives --remove  libnghttp2.14  $DIR/lib/libnghttp2.so.14
fi

