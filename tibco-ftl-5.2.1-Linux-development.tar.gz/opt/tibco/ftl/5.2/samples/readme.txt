/*
 * Copyright (c) 2009-2010 TIBCO Software Inc.
 * All Rights Reserved. Confidential & Proprietary.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 *
 * $Id: readme.txt 49614 2010-09-28 15:30:47Z $
 */

To compile java samples and run scripts in the various samples
subdirectories, do the following:

 1. Open console window and change directory to the samples
    subdirectory of your TIBCO FTL installation.

 2. Run "setup" script.

 3. Change directory to the appropriate place to compile or run scripts
