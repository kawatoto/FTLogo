#!/bin/sh

cd /root
tibpromgateway --push-gateway 127.0.0.1:9091 --realm-server "$@" &

pushgateway -web.listen-address 127.0.0.1:9091 -persistence.file /data/pushgateway/pushgateway_data &

cd /data/prometheus
/prometheus/prometheus -config.file /data/prometheus.yml -web.listen-address 0.0.0.0:9090 &

cd /grafana
/grafana/bin/grafana-server --config=/data/grafana.ini &

cd /root
( 	# Make sure Grafana is up and running
	until curl -u admin:admin -X GET http://127.0.0.1:3000/api/datasources
	do
		sleep 5
	done
	# Check if FTL datasource already exists
	if curl -u admin:admin -X GET http://127.0.0.1:3000/api/datasources | grep -q '"name"[[:space:]]*:[[:space:]]*"FTL' ; then
		true # Datasource already exists
	else
		curl -H "Content-Type: application/json" -d '{"name":"FTL","type":"prometheus","url":"http://127.0.0.1:9090","basicAuth":false,"access":"proxy","isDefault":true}' -u admin:admin -X POST http://127.0.0.1:3000/api/datasources
	fi
) &

[ -n "${TIB_ENTER_SHELL}" ] && exec /bin/bash

wait
