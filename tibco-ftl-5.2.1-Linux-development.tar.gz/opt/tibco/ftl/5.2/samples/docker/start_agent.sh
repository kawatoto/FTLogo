#!/bin/sh

#
# Copyright (c) 2010-2017 TIBCO Software Inc.
# All Rights Reserved. Confidential & Proprietary.
# For more information, please contact:
# TIBCO Software Inc., Palo Alto, California, USA
#
# $Id: start_agent.sh 92347 2017-03-15 20:51:02Z $
#

if [ -n "$TIB_NET_HOST" ]
then
    tibagent $@
    exit 1
fi

if [ -z "$DOCKER_SOCK" ]
then
    export DOCKER_SOCK=/var/run/docker.sock
fi

echo "DOCKER_SOCK is" $DOCKER_SOCK

if [ ! -e $DOCKER_SOCK ]
then
    echo "please map docker socket into container with:"
    echo "% docker run ... -v /var/run/docker.sock:/var/run/docker.sock ..."
    echo
    echo "if mapping is different from /var/run/docker.sock, specify actual"
    echo "docker socket path within container in DOCKER_SOCK:"
    echo "% export DOCKER_SOCK=/other/docker.sock"
    echo "or"
    echo "% docker run ... -e DOCKER_SOCK=/other/docker.sock ..."
    exit 1
fi

if [  -n "$TIB_EXTERNAL_HOST" ]
then
    echo "External host is" $TIB_EXTERNAL_HOST

    export TIB_DTCP_EXTERNAL="{$TIB_EXTERNAL_HOST}"
else
    docker_query -s $DOCKER_SOCK

    echo "Docker host candidate addresses:"
    cat /tmp/com.tibco.ftl.ipaddrs

    export TIB_DTCP_EXTERNAL="{$(head -1 /tmp/com.tibco.ftl.ipaddrs)"

    for addr in $(tail -n +2 /tmp/com.tibco.ftl.ipaddrs)
    do
        export TIB_DTCP_EXTERNAL="$TIB_DTCP_EXTERNAL;$addr"
    done

    export TIB_DTCP_EXTERNAL="$TIB_DTCP_EXTERNAL}"

    echo "RealmServers:"
    cat /tmp/com.tibco.ftl.rs

    # if we don't want to override -r address to docker bridge address,
    # do 'docker run -e TIB_RS_OVERRIDE=/ ...'
    if [ -z $TIB_RS_OVERRIDE ]
    then
	export TIB_RS_OVERRIDE=/tmp
    fi
fi

EXTERNAL_PORT=$(docker_query -s $DOCKER_SOCK -p 13139)

if [ -z "$EXTERNAL_PORT" ]
then
    echo "please expose container ports with:"
    echo "% docker run ... -P ..."
    exit 1
fi

echo "External port is" $EXTERNAL_PORT

export TIB_DTCP_EXTERNAL="$TIB_DTCP_EXTERNAL{13139/$EXTERNAL_PORT"

for INTERNAL_PORT in $(seq 13140 13148)
do
    EXTERNAL_PORT=$(docker_query -s $DOCKER_SOCK -p $INTERNAL_PORT)

    if [ -n "$EXTERNAL_PORT" ]
    then
        echo "External port is" $EXTERNAL_PORT
    
        export TIB_DTCP_EXTERNAL="$TIB_DTCP_EXTERNAL;$INTERNAL_PORT/$EXTERNAL_PORT"
    fi
done

export TIB_DTCP_EXTERNAL="$TIB_DTCP_EXTERNAL}"

tibagent -e $(docker_query -s $DOCKER_SOCK -p 13139) $@
