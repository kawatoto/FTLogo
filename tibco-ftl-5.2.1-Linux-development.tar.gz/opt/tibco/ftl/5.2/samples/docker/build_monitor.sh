#!/bin/sh

pushgateway_version=0.2.0
pushgateway_file=pushgateway-${pushgateway_version}.linux-amd64.tar.gz
pushgateway_url=https://github.com/prometheus/pushgateway/releases/download/${pushgateway_version}/${pushgateway_file}

prometheus_version=0.17.0
prometheus_dir=prometheus-${prometheus_version}.linux-amd64
prometheus_file=${prometheus_dir}.tar.gz
prometheus_url=https://github.com/prometheus/prometheus/releases/download/${prometheus_version}/${prometheus_file}

grafana_version=2.6.0
grafana_dir=grafana-${grafana_version}
grafana_file=${grafana_dir}.linux-x64.tar.gz
grafana_url=https://grafanarel.s3.amazonaws.com/builds/${grafana_file}

die () {
    echo "$@"
    exit 1
}

curl -L -O ${pushgateway_url} || die Could not fetch pushgateway
tar zxf ${pushgateway_file} || die Could not extract pushgateway
cp pushgateway /usr/bin || die No pushgateway file found

curl -L -O ${prometheus_url} || die Could not fetch prometheus
tar zxf ${prometheus_file} || die Coult not extract prometheus
mv ${prometheus_dir} /prometheus

curl -L -O ${grafana_url} || die Could not fetch grafana
tar zxf ${grafana_file} || die Could not extract grafana
mv ${grafana_dir} /grafana

# Leave no files behind to clutter up the image layer
rm -rf *
