/*
 * Copyright (c) 2009-2017 TIBCO Software Inc.
 * All Rights Reserved. Confidential & Proprietary.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 *
 * $Id: README.txt 92253 2017-03-10 22:01:54Z $
 */

Build RealmServer and Client Images
===================================

Set the environment variable FTL_INSTALL to the path where you
installed FTL.  Also set the FTL_EXTRACT variable to the path where
you have extracted FTL. Verify that the samples subdirectory is
present in the FTL_INSTALL directory.

% mkdir /tmp/build
% cd /tmp/build
% mkdir ftl

# copy the ftl debian packages.
% cp ${FTL_EXTRACT}/deb/*.deb ftl/
% cp -r ${FTL_INSTALL}/samples ftl/
% docker build -f ftl/samples/docker/Dockerfile.tibrealmserver -t ftl-tibrealmserver .
% docker build -f ftl/samples/docker/Dockerfile.monitor -t ftl-monitor .
% docker build -f ftl/samples/docker/Dockerfile.client -t ftl-client .
% docker build -f ftl/samples/docker/Dockerfile.tibstore -t ftl-tibstore .
% docker build -f ftl/samples/docker/Dockerfile.tibagent -t ftl-tibagent .

Start RealmServer
=================

% docker run -d -p 13131:13131 -p 13134:13134 ftl-tibrealmserver

The realm server URL is http://<host_name>:13131


Start Tibagent
===============
Start the tibagent before running the clients

% docker run -d --restart=unless-stopped -p 13139:13139 -p 13140:13140 -v /var/run/docker.sock:/var/run/docker.sock ftl-tibagent -rs <realmserver_host_name>:13131

Start Monitoring
================

Before starting the monitoring image for the first time:

% docker create --name=monitor_data ftl-monitor

Run Grafana:

% docker run -d -p 3000:3000 --volumes-from=monitor_data ftl-monitor discover://

Connect to Grafana from a browser:
  The Grafana URL is http://<host_name>:3000
  Supply the default login credentials for Grafana:
    Username: admin
    Password: admin

Persistent monitoring data and the Grafana configuration are stored in
a docker volume named monitor_data.


Run sample clients
==================

Load the sample realm configuration into the running realm server:

% docker run -it --rm ftl-client tibrealmadmin -rs <realmserver_host_name>:13131 -ur /opt/tibco/ftl/5.2/samples/scripts/tibrealmserver.json

Start tibrecvex:

% docker run -it --rm ftl-client tibrecvex -id tcp discover:// -c 600

Start tibsendex in a separate shell from tibrecvex:

% docker run -it --rm ftl-client tibsendex -id tcp discover:// -d 1000 -c 600



Setting the Prometheus scrape interval
======================================

The interval at which Prometheus scrapes data from the pushgateway is controlled by the `scrape_interval` line in the Prometheus configuration file (`prometheus.yml`). This file is stored in the `/data` directory of the monitor_data Docker volume.

To change this interval, instead of using the above command to start the ftl-monitor Docker container, use:

% docker run -ti -e TIB_ENTER_SHELL=1 -p 3000:3000 --volumes-from=monitor_data ftl-monitor discover://

This will open a shell on the running container. From here, navigate to the `/data` directory, and edit the `prometheus.yml` file. Any changes to this file will require Prometheus be restarted (restart the container).

The recommended value for `scrape_interval` is one-half of the Realm Server client-server heartbeat interval. If the `scrape_interval` value is too large, it is likely that samples can be missed. A very small value for `scrape_interval` will result in extra duplicate samples, adding no accuracy to the metrics but requiring much more storage in Prometheus.

Changes on the Realm Server to the client-server heartbeat interval may require adjustments to the `scrape_interval`.
