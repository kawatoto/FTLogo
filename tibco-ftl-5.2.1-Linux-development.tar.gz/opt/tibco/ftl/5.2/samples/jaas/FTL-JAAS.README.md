Using JAAS with tibrealmserver
==============================
Because JAAS is a Java based technology, it must be utilized from a Java environment.  This sample provides that capability using Jetty as a container.  The sample can be run as-is, using the provided .war file, or you can easily modify it to suit your needs.

Using the pre-compiled sample
-----------------------------
To install the FTL-JAAS.war file in Jetty from a fresh Jetty installation, follow these steps:

* Install jetty from https://eclipse.org/jetty/download.html
*  Add the FTL-JAAS.war file to the `demo-base/webapps` directory of the jetty installation.
*  Edit `demo-base/etc/login.conf` and add a `tibrealmserver` section.  See the sample files `ftl.jaas` and `ldap.jaas` for examples of how to do this. Make sure the users.txt in the 'tibrealmserver' section is an absolute path.
* Start your jetty server from with in the `demo-base` directory e.g. (d:\software\jetty\demo-base>java -jar ..\start.jar). By default the jetty server start at port 8080.
* Add `com.tibco.tibrealmserver.aas.url = http://<myhost>:<myport>/FTL-JAAS/login` to your realm server configuration file, or add `--aas.url http://<myhost>:<myport>/FTL-JAAS/login` to the realm server command line flags.
(e.g tibrealmserver --aas.url http://localhost:8080/FTL-JAAS/login -ht localhost:9090)

TIBCO strongly recommends that, in production, your Jetty instance should be protected with a user name and password, and have TLS (SSL) enabled as well.  Configuring this in Jetty is beyond the scope of this tutorial, but here are the needed realm server options:

`aas.user` --> The user name that the realm server will use to log into your Jetty instance.
`aas.password` --> The password that the realm server will use to log into your Jetty instance.
`aas.trust.file` --> The PEM certificate file specifying the certificate (or CA) of your Jetty instance.


Building the sample yourself
----------------------------
To compile the FTL-JAAS.war file yourself, use the 'jee' edition of [Eclipse](https://www.eclipse.org/downloads/), then follow these steps:

* Create a new "Dynamic Web" project in Eclipse
* In Properties-\>Java Build Path-\>Source, use the "Link Source" button to link $FTL\_HOME/samples/jaas/FTL-JAAS/WEB-INF/classes into the project.
* In Java Build Path-\>Libraries, use "Add External Jars" to add [json\_simple](https://code.google.com/archive/p/json-simple/) and [jetty](https://eclipse.org/jetty/) jar files to the classpath.
* In Properties-\>Deployment Assembly, choose Add-\>Java Build Path Entries, and pick the json\_simple jar file.
* Exit properties.  You should now have a working project.
* To create a WAR file for use in a Jetty server, right-click on the project, choose Export-\>WAR file, pick a location, and click Finish.
* Follow the steps above to install and use the WAR file in your Jetty instance.
