/*
 * Copyright (c) 2010-2017 TIBCO Software Inc.
 * All Rights Reserved. Confidential & Proprietary.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 *
 * $Id: FTLJettyLogin.java 91947 2017-03-01 22:35:57Z $
 */

package com.tibco.ftl.sample.tibrealmserver;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jetty.jaas.JAASLoginService;
import org.eclipse.jetty.jaas.JAASUserPrincipal;
import org.eclipse.jetty.jaas.callback.ObjectCallback;
import org.eclipse.jetty.jaas.callback.RequestParameterCallback;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * Servlet implementation class FTLJettyLogin
 */
@WebServlet(
        urlPatterns = { "/login" },
        initParams = { 
                @WebInitParam(name = "JAASRealm", value = "tibrealmserver,tibeftlserver", 
                        description = "Name of the section(s) of login.conf"),

                @WebInitParam(name = "verbose", value = "false", description = "Print debugging messages"),
        })

/*
 * Specify the JAAS file location using the java.security.auth.login.config property in
 * the app container configuration.
 */
public class FTLJettyLogin extends HttpServlet 
{
    private static final long serialVersionUID = 1L;
    private Map<String,JAASRealm> realmMap;
    boolean verbose = false;
    
    /* (non-Javadoc)
     * @see javax.servlet.GenericServlet#init()
     */
    @Override
    public void init() throws ServletException {
        super.init();
        
        verbose = "true".equals(getInitParameter("verbose"));

        realmMap = new HashMap<String,JAASRealm>();
        String realmList = getInitParameter("JAASRealm");
        for (String realmName: realmList.split(","))
        {
            if (verbose)
                System.out.println("Adding realm " + realmName);
            JAASRealm singleRealm = new JAASRealm();
            singleRealm.setName(realmName);
            singleRealm.setLoginModuleName(realmName);
            realmMap.put(realmName, singleRealm);
        }
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        JSONParser p = new JSONParser();
        Object o;

        try {
            o = p.parse(request.getReader());
        } catch (Exception e) {
            response.setStatus(400);
            response.getWriter().append("Invalid request at: ").append(request.getContextPath()).append("\n");
            response.getWriter().flush();
            return;
        }

        if (!(o instanceof JSONObject))
        {
            response.setStatus(400);
            response.getWriter().append("Invalid request at: ").append(request.getContextPath()).append("\n");
            response.getWriter().flush();
            return;
        }
        
        /*
         * We're expecting input with the form
         * { 
         *      "username" : "guest",
         *      "password" : "Z3Vlc3QtcHc=", 
         *      "meta":{
         *          "appname":"myapp"
         *          ...
         *      } 
         * }
         * 
         * Where password is base64 encoded, and meta may contain more fields.  (See below.)
         * 
         */
        JSONObject in = (JSONObject)o;
        
        if (verbose)
        {
            System.out.println(in.get("username").toString() + ": " + in.get("meta").toString());
        }

        String user = null;
        Object userObj = in.get("username");
        if (userObj != null && userObj instanceof String)
            user = Normalizer.normalize((String)userObj, Normalizer.Form.NFC);
        
        String password = null;
        Object passwdObj = in.get("password");
        if (passwdObj != null && passwdObj instanceof String)
        {
            password = new String(Base64.getDecoder().decode((String) passwdObj), StandardCharsets.UTF_8);
            password = Normalizer.normalize(password, Normalizer.Form.NFC);
        }
                
        JSONObject jsonObject = null;
        Object temp = in.get("meta");
        if (temp != null && temp instanceof JSONObject)
            jsonObject = (JSONObject)temp;
        
        String realmName = null;
        Object realmNameObject = jsonObject.get("realm");
        if (realmNameObject != null && realmNameObject instanceof String)
            realmName = (String)realmNameObject;
        
        JAASRealm jaasRealm = null;
        if (realmName != null && !"".equals(realmName))
        {
            synchronized (realmMap) {
                jaasRealm = realmMap.get(realmName);
            }
        }

        Collection<String> roles = null;
        boolean loggedIn = false;
        if (jaasRealm != null)
        {
            if (verbose)
                System.out.println("Realm name is: " + jaasRealm.getName());
            roles = jaasRealm.login(user, password, jsonObject);
            loggedIn = roles != null;
        }
        else
        {
            if (verbose)
                System.out.println("No realm name from request.");
        }

        /*
         * We should generate output like this:
         * {
         *      "authenticated":true,
         *      "roles":["role1", "role2", ...]
         * }
         * 
         * If access is denied, then "authenticated" should be false, and there is no
         * need for a "roles" field.
         */
        JSONObject ro = new JSONObject();
        ro.put("authenticated", loggedIn);
        
        if (loggedIn) 
        {
            JSONArray roleArray = new JSONArray();
            for (String role: roles)
                roleArray.add(role);
            ro.put("roles", roleArray);
        }

        if (verbose)
            System.out.println(ro.toJSONString());

        response.setContentType("application/json");
        ro.writeJSONString(response.getWriter());
        response.getWriter().append("\n");
        response.getWriter().flush();
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        doGet(request, response);
    }
    
    private static class LoginCallbackHandler implements CallbackHandler
    {
        private String username;
        private String password;
        private JSONObject parameters;
        private String parametersName;
       
        public LoginCallbackHandler(String username, String password, JSONObject jsonObject, String parametersName)
        {
            this.username = username;
            this.password = password;
            this.parameters = jsonObject;
            this.parametersName = parametersName;
        }

        @Override
        public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException
        {
            for (Callback callback : callbacks)
            {
                if (callback instanceof NameCallback)
                {
                    ((NameCallback)callback).setName(username);
                }
                else if (callback instanceof PasswordCallback)
                {
                    if (password != null)
                    {
                        ((PasswordCallback)callback).setPassword(password.toCharArray());
                    }
                }
                else if (callback instanceof ObjectCallback)
                {
                    ((ObjectCallback)callback).setObject(password);
                }
                else if (callback instanceof RequestParameterCallback)
                {
                    String name = ((RequestParameterCallback)callback).getParameterName();
                    if (parameters != null && name.equals(parametersName))
                    {
                        ArrayList<String> l = new ArrayList<String>(4);
                        l.add("com.tibco.ftl.appname:" + (String)parameters.get("appname"));
                        l.add("com.tibco.ftl.client_host:" + (String)parameters.get("host"));    
                        l.add("com.tibco.ftl.client_ip_address:" + (String)parameters.get("client_ip_address"));
                        l.add("com.tibco.ftl.client_version:" + (String)parameters.get("version"));
                        ((RequestParameterCallback)callback).setParameterValues(l);
                    }
                    else 
                    {
                        ArrayList <String> l = new ArrayList<String>();
                        ((RequestParameterCallback)callback).setParameterValues(l);
                    }
                }
                else
                {
                    throw new UnsupportedCallbackException(callback);
                }
            }
        }
    }
    
    public class JAASRealm extends JAASLoginService
    {

        public Collection<String> login(String username, String credentials, JSONObject jsonObject) {
            Collection<String> roles = null;
                        
            if(username!=null && credentials!=null)
            {
                LoginContext loginContext = null;

                try
                {
                    Subject subject = new Subject();
                    loginContext = new LoginContext(getName(), subject, 
                                            new LoginCallbackHandler(username, credentials, jsonObject, "com.tibco.ftl.parameters"));
                        
                    loginContext.login();
                    
                    // This code taken in principal from Jetty's JAASLoginService.
                    JAASUserPrincipal userPrincipal = new JAASUserPrincipal(username, subject, loginContext);
                    subject.getPrincipals().add(userPrincipal);
                        
                    String[] roleClassNames = getRoleClassNames();
                    roles = new LinkedHashSet<String>();
                    for (String roleClassName: roleClassNames)
                    {
                        try 
                        {
                            @SuppressWarnings("unchecked")
                            Class<? extends Principal> roleClass = 
                                    (Class<? extends Principal>) Thread.currentThread().getContextClassLoader()
                                        .loadClass(roleClassName);
                            Set<? extends Principal> principals = subject.getPrincipals(roleClass);
                            for (Principal role : principals)
                                roles.add(role.getName());
                        } 
                        catch (ClassNotFoundException e) {}
                    }
                }
                catch (LoginException e)
                {
                    // Nothing to do here, since roles == null already.
                }
                finally {
                    try {
                        if (loginContext != null)
                            loginContext.logout();
                    } catch (Exception e) {}
               }
            }
                        
            return roles;
        }
    }
}
