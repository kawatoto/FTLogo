#include <stdio.h>
#include <unistd.h>
#include "tib/ftl.h"

int main(int argc, char** argv)
{
    tibEx ex = NULL;
    tibRealm realm = NULL;
    tibPublisher pub = NULL;
    tibMessage msg = NULL;
    long seq;

    ex = tibEx_Create();
    tib_Open(ex, TIB_COMPATIBILITY_VERSION);
    realm = tibRealm_Connect(ex, "http://localhost:8080", NULL, NULL);

    pub = tibPublisher_Create(ex, realm, NULL, NULL);

    msg = tibMessage_Create(ex, realm, NULL);
    tibMessage_SetString(ex, msg, "type", "hello");
    tibMessage_SetString(ex, msg, "contents", "hello world");

    printf("sending 'hello world' messages\n"); 
    fflush(stdout);
    for (seq = 1; seq <= 5; ++seq)
    {
        tibMessage_SetLong(ex, msg, "seq", seq);
        tibPublisher_Send(ex, pub, msg);
        sleep(1);
    }

    tibMessage_Destroy(ex, msg);
    tibPublisher_Close(ex, pub);

    tibRealm_Close(ex, realm);
    tib_Close(ex);
    tibEx_Destroy(ex);

    return 0;
}