#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "tib/ftl.h"
#include "common.h"

#define DEFAULT_REALM_SERVER "http://localhost:8080"
#define DEFAULT_APPLICATION NULL
#define DEFAULT_ENDPOINT NULL
#define DEFAULT_MSG_COUNT 20

const char * RealmServer = DEFAULT_REALM_SERVER;
const char * Application = DEFAULT_APPLICATION;
const char * Endpoint = DEFAULT_ENDPOINT;
tibint64_t MsgCount = DEFAULT_MSG_COUNT;

const char * Options = "a:c:e:hr:";

void print_usage(void)
{
    fprintf(stderr,
        "Usage: ftlpub [options]\n"
        "  -a APPLICATION       set application name\n"
        "  -c COUNT             send COUNT data messages\n"
        "  -e ENDPOINT          set endpoint name\n"
        "  -h                   print this help\n"
        "  -r URL               use realm server URL\n"
    );
    exit(1);
}

void parse_arguments(int argc, char ** argv)
{
    int opt;

    while ((opt = getopt(argc, argv, Options)) != -1)
    {
        switch (opt)
        {
            case 'a':
                Application = strdup(optarg);
                break;
            case 'c':
                MsgCount = (tibint64_t) atoi(optarg);
                break;
            case 'e':
                Endpoint = strdup(optarg);
                break;
            case 'r':
                RealmServer = strdup(optarg);
                break;
            case 'h':
            case '?':
            default:
                print_usage();
                break;
        }
    }
}

int main(int argc, char** argv)
{
    tibEx ex = NULL;
    tibRealm realm = NULL;
    tibPublisher pub = NULL;
    tibMessage msg = NULL;
    tibint64_t idx;

    parse_arguments(argc, argv);

    ex = tibEx_Create();
    tib_Open(ex, TIB_COMPATIBILITY_VERSION);
    realm = tibRealm_Connect(ex, RealmServer, Application, NULL);

    pub = tibPublisher_Create(ex, realm, Endpoint, NULL);
    CHECK(ex);

    msg = tibMessage_Create(ex, realm, NULL);
    CHECK(ex);

    printf("using Realm Server=%s\n\tApplication=%s\n\tEndpoint=%s\n",
        RealmServer,
        (Application != NULL ? Application : "default"),
        (Endpoint != NULL ? Endpoint : "default"));
    printf("sending initial message\n");
    fflush(stdout);
    tibMessage_SetString(ex, msg, FIELD_NAME_TAG, FIELD_TAG_CONTROL);
    tibMessage_SetString(ex, msg, FIELD_NAME_CONTENTS, "Initial message");
    tibMessage_SetLong(ex, msg, FIELD_NAME_COUNT, MsgCount);
    tibMessage_SetLong(ex, msg, FIELD_NAME_BOS, 1);
    tibPublisher_Send(ex, pub, msg);
    CHECK(ex);

    tibMessage_SetString(ex, msg, FIELD_NAME_TAG, FIELD_TAG_DATA);
    tibMessage_ClearField(ex, msg, FIELD_NAME_COUNT);
    tibMessage_ClearField(ex, msg, FIELD_NAME_BOS);
    tibMessage_SetString(ex, msg, FIELD_NAME_CONTENTS, "Data message");

    printf("sending %" PRId64 " data messages\n", MsgCount); 
    fflush(stdout);

    for (idx = 1; idx <= MsgCount; ++idx)
    {
        tibMessage_SetLong(ex, msg, FIELD_NAME_SEQ, idx);
        if ((idx % 2) == 0)
        {
            tibMessage_SetLong(ex, msg, FIELD_NAME_EVEN, 1);
        }
        else
        {
            tibMessage_SetLong(ex, msg, FIELD_NAME_EVEN, 0);
        }
        tibPublisher_Send(ex, pub, msg);
        CHECK(ex);
        sleep(1);
    }

    printf("sending final message\n");
    fflush(stdout);
    tibMessage_ClearAllFields(ex, msg);
    tibMessage_SetString(ex, msg, FIELD_NAME_TAG, FIELD_TAG_CONTROL);
    tibMessage_SetString(ex, msg, FIELD_NAME_CONTENTS, "Final message");
    tibMessage_SetLong(ex, msg, FIELD_NAME_COUNT, MsgCount);
    tibMessage_SetLong(ex, msg, FIELD_NAME_EOS, 1);
    tibPublisher_Send(ex, pub, msg);
    CHECK(ex);

    tibMessage_Destroy(ex, msg);
    tibPublisher_Close(ex, pub);

    tibRealm_Close(ex, realm);
    tib_Close(ex);
    CHECK(ex);
    tibEx_Destroy(ex);

    return 0;
}