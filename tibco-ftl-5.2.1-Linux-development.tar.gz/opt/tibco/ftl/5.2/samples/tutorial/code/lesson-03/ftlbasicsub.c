#include <stdio.h>
#include "tib/ftl.h"
#include "common.h"

void onMessages(tibEx ex, tibEventQueue msgQueue, tibint32_t msgNum, tibMessage *msgs,
                void **closures)
{
    tibint32_t i;
    char buffer[1024];

    for (i = 0; i < msgNum; i++)
    {
        printf("received message\n");
        (void)tibMessage_ToString(ex, msgs[i], buffer, sizeof(buffer));
        printf("  %s\n", buffer);
        fflush(stdout);
    }
}

int main(int argc, char** argv)
{
    tibEx ex = NULL;
    tibRealm realm = NULL;
    tibEventQueue queue = NULL;
    tibSubscriber sub = NULL;

    ex = tibEx_Create();
    tib_Open(ex, TIB_COMPATIBILITY_VERSION);
    realm = tibRealm_Connect(ex, "http://localhost:8080", NULL, NULL);

    sub = tibSubscriber_Create(ex, realm, NULL, NULL, NULL);
    queue = tibEventQueue_Create(ex, realm, NULL);
    tibEventQueue_AddSubscriber(ex, queue, sub, onMessages, NULL);
    CHECK(ex);

    printf("waiting for message(s)\n");
    fflush(stdout);
    do
    {
        tibEventQueue_Dispatch(ex, queue, TIB_TIMEOUT_WAIT_FOREVER);
    } while (tibEx_GetErrorCode(ex) == TIB_OK);

    tibEventQueue_RemoveSubscriber(ex, queue, sub, NULL);
    tibEventQueue_Destroy(ex, queue, NULL);
    tibSubscriber_Close(ex, sub);

    tibRealm_Close(ex, realm);
    tib_Close(ex);
    CHECK(ex);
    tibEx_Destroy(ex);

    return 0;
}