#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "tib/ftl.h"
#include "common.h"

#define DEFAULT_REALM_SERVER "http://localhost:8080"
#define DEFAULT_APPLICATION NULL
#define DEFAULT_ENDPOINT NULL

const char * RealmServer = DEFAULT_REALM_SERVER;
const char * Application = DEFAULT_APPLICATION;
const char * Endpoint = DEFAULT_ENDPOINT;
const char * Matcher = NULL;
tibbool_t Verbose = tibfalse;

tibbool_t Done = tibfalse;
tibint64_t DataMsgsReceived = 0;
tibint64_t ControlMsgsReceived = 0;
tibint64_t ExpectedMsgCount = 0;

const char * Options = "a:e:hm:r:v";

void print_usage(void)
{
    fprintf(stderr,
        "Usage: ftlpub [options]\n"
        "  -a APPLICATION       set application name\n"
        "  -e ENDPOINT          set endpoint name\n"
        "  -h                   print this help\n"
        "  -m CONTENT           use matcher\n"
        "  -r URL               use realm server URL\n"
        "  -v                   verbose output\n"
    );
    exit(1);
}

void parse_arguments(int argc, char ** argv)
{
    int opt;

    while ((opt = getopt(argc, argv, Options)) != -1)
    {
        switch (opt)
        {
            case 'a':
                Application = strdup(optarg);
                break;
            case 'e':
                Endpoint = strdup(optarg);
                break;
            case 'm':
                Matcher = strdup(optarg);
                break;
            case 'r':
                RealmServer = strdup(optarg);
                break;
            case 'v':
                Verbose = tibtrue;
                break;
            case 'h':
            case '?':
            default:
                print_usage();
                break;
        }
    }
}

void onMessages(tibEx ex, tibEventQueue msgQueue, tibint32_t msgNum, tibMessage *msgs,
                void **closures)
{
    tibint32_t i;
    char buffer[1024];
    static tibbool_t init_received = tibfalse;
    const char * type = NULL;

    for (i = 0; i < msgNum; i++)
    {
        if (Verbose)
        {
            printf("received message\n");
            (void)tibMessage_ToString(ex, msgs[i], buffer, sizeof(buffer));
            printf("  %s\n", buffer);
            fflush(stdout);
        }
        if (!tibMessage_IsFieldSet(ex, msgs[i], FIELD_NAME_TAG))
        {
            printf("%s field is not present in received message\n", FIELD_NAME_TAG);
            fflush(stdout);
            continue;
        }
        type = tibMessage_GetString(ex, msgs[i], FIELD_NAME_TAG);
        if (strcmp(type, FIELD_TAG_CONTROL) == 0)
        {
            ControlMsgsReceived++;
            if (init_received)
            {
                /* Looking for eos */
                if (tibMessage_IsFieldSet(ex, msgs[i], FIELD_NAME_EOS))
                {
                    printf("received EOS indicator\n");
                    fflush(stdout);
                    Done = tibtrue;
                }
                else
                {
                    printf("received unexpected control message\n");
                    fflush(stdout);
                }
            }
            else
            {
                /* looking for bos */
                if (tibMessage_IsFieldSet(ex, msgs[i], FIELD_NAME_BOS))
                {
                    init_received = tibtrue;
                    printf("received BOS indicator\n");
                    fflush(stdout);
                    ExpectedMsgCount = tibMessage_GetLong(ex, msgs[i], FIELD_NAME_COUNT);
                }
                else
                {
                    printf("received unexpected control message\n");
                    fflush(stdout);
                }
            }
        }
        else if (strcmp(type, FIELD_TAG_DATA) == 0)
        {
            DataMsgsReceived++;
            if (init_received)
            {
                if (Verbose)
                {
                    if (tibMessage_IsFieldSet(ex, msgs[i], FIELD_NAME_SEQ))
                    {
                        tibint64_t seq = tibMessage_GetLong(ex, msgs[i], FIELD_NAME_SEQ);
                        printf("received data seq %" PRId64"\n", seq);
                    }
                    else
                    {
                        printf("%s field not present in received message\n", FIELD_NAME_SEQ);
                    }
                    fflush(stdout);
                }
            }
            else
            {
                printf("received unexpected data message\n");
                fflush(stdout);
            }
        }
        else
        {
            printf("received unexpected message\n");
            fflush(stdout);
        }
    }
}

int main(int argc, char** argv)
{
    tibEx ex = NULL;
    tibRealm realm = NULL;
    tibEventQueue queue = NULL;
    tibSubscriber sub = NULL;
    tibContentMatcher cm = NULL;

    parse_arguments(argc, argv);

    ex = tibEx_Create();
    tib_Open(ex, TIB_COMPATIBILITY_VERSION);
    realm = tibRealm_Connect(ex, RealmServer, Application, NULL);

    if (Matcher != NULL)
    {
        cm = tibContentMatcher_Create(ex, realm, Matcher);
        CHECK(ex);
    }
    sub = tibSubscriber_Create(ex, realm, Endpoint, cm, NULL);
    if (cm != NULL)
    {
        tibContentMatcher_Destroy(ex, cm);
    }
    queue = tibEventQueue_Create(ex, realm, NULL);
    tibEventQueue_AddSubscriber(ex, queue, sub, onMessages, NULL);
    CHECK(ex);

    printf("using Realm Server=%s\n\tApplication=%s\n\tEndpoint=%s\n\tMatcher=%s\n",
        RealmServer,
        (Application != NULL ? Application : "default"),
        (Endpoint != NULL ? Endpoint : "default"),
        (Matcher != NULL ? Matcher: "none"));
    printf("waiting for message(s)\n");
    fflush(stdout);
    do
    {
        tibEventQueue_Dispatch(ex, queue, TIB_TIMEOUT_WAIT_FOREVER);
    } while (!Done && tibEx_GetErrorCode(ex) == TIB_OK);

    printf("Received %" PRId64 " control, and %" PRId64 " of %" PRId64 " data messages.\n",
        ControlMsgsReceived, DataMsgsReceived, ExpectedMsgCount);
    fflush(stdout);
    tibEventQueue_RemoveSubscriber(ex, queue, sub, NULL);
    tibEventQueue_Destroy(ex, queue, NULL);
    tibSubscriber_Close(ex, sub);

    tibRealm_Close(ex, realm);
    tib_Close(ex);
    CHECK(ex);
    tibEx_Destroy(ex);

    return 0;
}
