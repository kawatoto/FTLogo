#if !defined(COMMON_H_INCLUDED)
#define COMMON_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "tib/ftl.h"

#define CHECK(ex) \
{                                                       \
    if(tibEx_GetErrorCode(ex) != TIB_OK)                \
    {                                                   \
       char exStr[1024];                                \
       fprintf(stderr, "%s: %d\n", __FILE__, __LINE__); \
       tibEx_ToString(ex, exStr, sizeof(exStr));        \
       fprintf(stderr, "%s\n", exStr);                  \
       tib_Close(ex);                                   \
       exit(-1);                                        \
    }                                                   \
}

#endif
