/*
 * Copyright (c) 2010-2016 TIBCO Software Inc.
 * All Rights Reserved. Confidential & Proprietary.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 *
 * $Id: readme.txt 90137 2016-12-13 19:04:42Z $
 */

This directory contains simple scripts to quickly start FTL components.  To
use these, do the following steps first.


 1. Open console window and change directory to the samples
    subdirectory of your TIBCO FTL installation.

 2. run "setup" script.

 3. Change directory to samples/scripts


To start a simple realm server, use the ftlstart script
with the "single" and "realm" arguments which starts a realm server
and updates this realm with the tibrealmserver.json file.  This uses a
specified host and port or if none is provided it uses the default
"localhost:8080".  This logs to a directory specific for this user.

To stop the simple realm server, use the ftlstop script with the
"single" and "realm" arguments and the same host:port given to the
ftlstart script.

To start/stop a fault-tolerant realm server pair use the ftlstart and
ftlstop scripts with the "ft" and "realm" arguments.

To start/stop a satellite realm server use the ftlstart and ftlstop
scripts with the "single" or "ft" argument and the "satellite"
argument.

To analyze the output from the tiblatsend --out option, use the
analyze-tiblatsend script.  Supply the file name as a command line
parameter, and analyze-tiblatsend will output statistics such as
median latency, percentile performance, and mean latency with standard
deviation.

There are sample python scripts that demonstrate how to write a python
script to get information or update the realm configuration directly
from the python API.  See the individual scripts to understand their
functionality.

