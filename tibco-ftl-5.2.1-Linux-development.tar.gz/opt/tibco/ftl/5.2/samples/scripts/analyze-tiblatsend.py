#!/usr/bin/env python

# Copyright (c) 2009-2016 TIBCO Software Inc.
# All Rights Reserved. Confidential & Proprietary.
# For more information, please contact:
# TIBCO Software Inc., Palo Alto, California, USA

# $Id: analyze-tiblatsend.py 90137 2016-12-13 19:04:42Z $

import sys
import csv
import math

"""analyze-tiblatsend will read the csv output from the tiblatsend command.
To generate one of these files, use the --out flag for tiblatsend.  Then
run analyze-tiblatsend and give the file name as the command line parameter.
You can aggregate the results from many runs by giving all the related
files.
"""

def eng_string(n):
    if n == 0.0:
        return "   0.00E+00"
    
    if n < 0:
        negative = True
        n = -n
    else:
        negative = False
    
    power = math.floor(math.log10(n)/3.0)*3.0
    factor = math.exp(power * math.log(10))
    
    value = "%3.2fE%+03d" % (n/factor, power)
    if negative:
        value = "-" + value
    else:
        value = " " + value
        
    return " " * (11-len(value)) + value

def read_samples(fname, samples):
    print "Reading " + fname + "...",
    sys.stdout.flush()

    sfile = open(fname, "rb")
    for row in csv.reader(sfile):
	    if len(row) <= 0:
			continue
	    else:
			samples.append(float(row[1]))
    sfile.close()
    print "done."

    print "%d samples read so far." % len(samples)

def under_percent(p, samples):
    index = int(math.ceil(p * (len(samples)-1) / 100.0))
    value = samples[index]
    print "%5s%% of samples less than or equal to " % str(p) + eng_string(value)
    return value

def get_mean(samples):
    min = float("+inf")
    max = float("-inf")
    n = 0
    mean = 0.0
    M2 = 0.0
    for x in samples:
        if (x < min):
            min = x
        if (x > max):
            max = x
        n += 1
        delta = x - mean
        mean += delta/n
        M2 += delta * (x - mean)
        
    return (min,max,mean,math.sqrt(M2/n))

if __name__ == "__main__":
    samples = [];
    for arg in sys.argv[1:]:
        read_samples(arg, samples)

    num_samples = len(samples)
    print "Total of " + eng_string(num_samples) + " samples."

    print "Sorting samples...",
    sys.stdout.flush()
    samples.sort()
    print "done."
    print
    
    if num_samples > 0:
		if num_samples % 2:
			# Odd number of samples
			median = samples[num_samples/2]
		else:
			# Even number of samples
			median = (samples[num_samples/2-1] + samples[num_samples/2]) / 2
		print "Median value is: " + eng_string(median)

		under_percent(90.0, samples)
		under_percent(99.0, samples)
		under_percent(99.9, samples)
		under_percent(99.99, samples)
		print
    
		print "Calculating mean...",
		sys.stdout.flush()
		(min, max, mean, deviation) = get_mean(samples)
		print "done."
		print "min/max/mean/dev:",
		print eng_string(min),
		print eng_string(max),
		print eng_string(mean),
		print eng_string(deviation)
		print
