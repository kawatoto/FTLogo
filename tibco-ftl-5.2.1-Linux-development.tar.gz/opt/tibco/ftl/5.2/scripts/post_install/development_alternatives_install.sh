#!/bin/bash

DIR=/opt/tibco/ftl/5.2

if [ -e /etc/redhat-release ]
then
  alternatives  --install /usr/include/tib      tib       $DIR/include/tib 100
  alternatives  --install /usr/include/tibgroup tibgroup  $DIR/include/tibgroup 100
elif [ -e /etc/debian_version ] || [ -e /etc/SuSE-release ]
then
  update-alternatives --install /usr/include/tib      tib       $DIR/include/tib 100
  update-alternatives --install /usr/include/tibgroup tibgroup  $DIR/include/tibgroup 100
fi

