#!/bin/bash

DIR=/opt/tibco/ftl/5.2

if [ -e /etc/redhat-release ]
then
  alternatives  --remove  tib       $DIR/include/tib
  alternatives  --remove  tibgroup  $DIR/include/tibgroup
elif [ -e /etc/debian_version ] || [ -e /etc/SuSE-release ]
then
  update-alternatives --remove  tib       $DIR/include/tib
  update-alternatives --remove  tibgroup  $DIR/include/tibgroup
fi
